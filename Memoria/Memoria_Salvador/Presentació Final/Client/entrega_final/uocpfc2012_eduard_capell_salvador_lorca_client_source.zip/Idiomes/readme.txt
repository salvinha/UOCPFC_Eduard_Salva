[UOC] Projecte Final de Carrera
Alumnes: Capell Brufau, Eduard i Lorca Sans, Salvador
Consultor: Roset Mayals, Roman
App: Aprenentatge d'Idiomes

Funcionament del projecte: L�aplicaci� en m�bils permet la gesti� de les llistes d�estudi i les paraules, m�s la visualitzaci� de les flashcards. Les caracter�stiques principals s�n les seg�ents:
	- Personalitzaci� de les llistes: Possibilitat de crear noves llistes d�estudi i d�afegir/modificar/esborrar elements a aquestes llistes. Per exemple: Dies de la setmana, mesos de l�any, colors, n�meros, coses d'un hotel, aliments, etc.
	- Gesti� d�un diccionari de paraules: Creaci�, modificaci� i esborrat de paraules que proveiran les llistes d�estudi.
	- Visualitzaci� de les flashcards: Despla�ament entre fitxes amb opci� per escoltar com es pronuncia la paraula que cont� i presentaci� de les fitxes usant la metodologia del sistema Leitner
